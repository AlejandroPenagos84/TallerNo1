/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

/*•	Javier Alejandro Penagos Hernández - 20221020028
•	David Esteban Sainea Rubio - 20221020025
•	Tomas Cardenas Benitez  -  20221020021
*/
/**
 *
 * @author Alejandro Penagos
 */
public class Launcher {
    public static void main(String[] args){
        new Control();
    }
}
